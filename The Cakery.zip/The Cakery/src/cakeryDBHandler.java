import java.sql.*;
import java.util.Date;

public class cakeryDBHandler {
    Connection connect = null;
    public cakeryDBHandler() {
        connectDatabase(); // Call the connectDatabase method in the constructor
    }

    public boolean connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connect = DriverManager.getConnection("jdbc:mysql://localhost/sample_db", "malik", "5570");
            return true;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public ResultSet userLoginQuery(String username, String password) {
        try {
            String query = "SELECT username, password FROM customer WHERE username = ? AND password = ?";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, username);
            pStatement.setString(2, password);
            return pStatement.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public ResultSet empLoginQuery(String uname, String pass){
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM employee WHERE emp_uname=? AND password=?";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, uname);
            pStatement.setString(2, pass);
            resultSet = pStatement.executeQuery();
            System.out.println("Successfully Executed Employee Login Query..");
        } catch(Exception e){
            System.out.println("Error in Employee Login Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public ResultSet testQuery(){
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM customer";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Test Query..");
        } catch(Exception e){
            System.out.println("Error in Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public void showResult(ResultSet resultSet) {
        try {
            while(resultSet.next()){
                int id = resultSet.getInt("customer_id");
                String fname = resultSet.getString("fullname");
                String uname = resultSet.getString("username");
                String email = resultSet.getString("email");
                String password = resultSet.getString("password");
                String address = resultSet.getString("address");
                String cellno = resultSet.getString("cellno");
                System.out.println(id + "\t" + fname + "\t" + uname + "\t" + email + "\t" + password + "\t" + address + "\t" + cellno);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public boolean insertData(String fname, String uname, String email, String password, String address, String cellno){
        try {
            String query = "INSERT INTO customer (fullname, username, email, password, address, cellno) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, fname);
            pStatement.setString(2, uname);
            pStatement.setString(3, email);
            pStatement.setString(4, password);
            pStatement.setString(5, address);
            pStatement.setString(6, cellno);
            pStatement.executeUpdate();
            System.out.println("Successfully Inserted Customer Data..");
            return true;
        } catch(Exception e){
            System.out.println("Error in Inserting Customer Data..");
            e.printStackTrace();
            return false;
        }
    }

    public boolean insertOrderData(String customerid, String itemid, Date date, String quantity, String ordertype){
        try {
            String query = "INSERT INTO orders (customer_id, item_id, date, quantity, order_type) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, customerid);
            pStatement.setString(2, itemid);
            pStatement.setDate(3, new java.sql.Date(date.getTime()));
            pStatement.setString(4, quantity);
            pStatement.setString(5, ordertype);
            pStatement.executeUpdate();
            System.out.println("Successfully Inserted Order Data..");
            return true;
        } catch(Exception e){
            System.out.println("Error in Inserting Order Data..");
            e.printStackTrace();
            return false;
        }
    }

    public void logindata(String uname, String password){
        try {
            String query = "SELECT username, password FROM customer WHERE username = ? AND password = ?";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, uname);
            pStatement.setString(2, password);
            pStatement.executeUpdate();
            System.out.println("Successfully Executed Login Data Query..");
        } catch(Exception e){
            System.out.println("Error in Login Data Query..");
            e.printStackTrace();
        }
    }

    public void employeelogindata(String uname, String password){
        try {
            String query = "SELECT emp_uname, password FROM employee WHERE emp_uname = ? AND password = ?";
            PreparedStatement pStatement = connect.prepareStatement(query);
            pStatement.setString(1, uname);
            pStatement.setString(2, password);
            pStatement.executeUpdate();
            System.out.println("Successfully Executed Employee Login Data Query..");
        } catch(Exception e){
            System.out.println("Error in Employee Login Data Query..");
            e.printStackTrace();
        }
    }

    public ResultSet EmployeetestQuery(){
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM employee";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Employee Test Query..");
        } catch(Exception e){
            System.out.println("Error in Employee Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public void EmployeeshowResult(ResultSet resultSet) {
        try {
            while(resultSet.next()){
                int id = resultSet.getInt("emp_id");
                String name = resultSet.getString("emp_name");
                String uname = resultSet.getString("emp_uname");
                String password = resultSet.getString("password");
                String cellno = resultSet.getString("emp_cellno");
                String position = resultSet.getString("position");
                double salary = resultSet.getDouble("salary");
                Date joindate = resultSet.getDate("join_date");
                Date leftdate = resultSet.getDate("left_date");
                System.out.println(id + "\t" + name + "\t" + uname + "\t" + password + "\t" + cellno + "\t" + position + "\t" + salary + "\t" + joindate + "\t" + leftdate + "\n");
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public ResultSet ItemtestQuery(){
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM items";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Item Test Query..");
        } catch(Exception e){
            System.out.println("Error in Item Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public void ItemshowResult(ResultSet resultSet) {
        try {
            while(resultSet.next()){
                int id = resultSet.getInt("item_id");
                String name = resultSet.getString("item_name");
                double price = resultSet.getDouble("item_price");
                String type = resultSet.getString("item_type");
                System.out.println(id + "\t" + name + "\t" + price + "\t" + type + "\n");
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public ResultSet OrdertestQuery(){
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM orders";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Order Test Query..");
        } catch(Exception e){
            System.out.println("Error in Order Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public void OrdershowResult(ResultSet resultSet) {
        try {
            while(resultSet.next()){
                int id = resultSet.getInt("order_id");
                int custid = resultSet.getInt("customer_id");
                int itemid = resultSet.getInt("item_id");
                Date date = resultSet.getDate("date");
                int quantity = resultSet.getInt("quantity");
                String ordertype = resultSet.getString("order_type");
                System.out.println(id + "\t" + custid + "\t" + itemid + "\t" + date + "\t" + quantity + "\t" + ordertype + "\n");
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    public ResultSet paymentTestQuery() {
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM payment";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Payment Test Query..");
        } catch(Exception e){
            System.out.println("Error in Payment Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }

    public ResultSet PaymenttestQuery() {
        ResultSet resultSet = null;
        try {
            String query = "SELECT * FROM payment";
            Statement statement = connect.createStatement();
            resultSet = statement.executeQuery(query);
            System.out.println("Successfully Executed Payment Test Query..");
        } catch(Exception e){
            System.out.println("Error in Payment Test Query..");
            e.printStackTrace();
        }
        return resultSet;
    }


}
